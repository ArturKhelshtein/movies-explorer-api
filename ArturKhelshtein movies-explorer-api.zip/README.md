# movies-explorer-api
Репозиторий для бэкенда дипломного проекта `Movies-explorer`, со следующими возможностями: авторизация и регистрации пользователей, операции с фильмами и пользователями.

Адрес репозитория: https://github.com/ArturKhelshtein/movies-explorer-api

Backend https://api.arturkhelshtein.nomoredomainsicu.ru
